---
title: Sample Post 2
description: Meta description for Sample Post 2
canonical: https://markbase-template-blog.vercel.app
ogUrl: https://markbase-template-blog.vercel.app
ogTitle: Sample Post 2 OG Title
ogDescription: Sample Post 2 OG Description
ogImage: https://images.unsplash.com/photo-1651672263604-fb502b92f6fe?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=465&q=80
ogSitename: Markbase Template Blog
twitterHandle: "@markbasedev"
twitterSite: "@markbasedev"
twitterCardType: summary_large_image
---

# Sample Post 2

[Sample Post 1](./sample-post1.md)

[Sample Child Post 1](./sample-folder/sample-child-post1.md)

[Sample External Link](https://tressel.xyz)

## H2
### H3
#### H4

# Sample Post

Here's what a bunch of Markdown looks like on Markbase!

## Highlights

You can highlight ==important parts of your text== using two equals signs followed by text to highlight and then closed with two equals signs again.

## Links

External links (to sites outside this domain) look like [this](https://tressel.xyz)

Internal links (to your own Markdown files) **hover** and look like [this](../Home.md).

## Quotes

> For the first time in history, we have instantaneous access to the world’s knowledge. There has never been a better time to learn, to contribute, and to improve ourselves. Yet, rather than feeling empowered, we are often left feeling overwhelmed by this constant influx of information.

> They can be split into
> Multiple lines
> Too

## Callouts

> [!NOTE] 
> A simple note callout

> [!SUMMARY]
> A simple summary/abstract/tldr callout

> [!INFO]
> A simple info/todo callout

> [!TIP]
> A simple tip/hint/important callout

> [!SUCCESS]
> A simple success/check/done callout

> [!QUESTION]
> A simple question/help/faq callout

> [!WARNING]
> A simple warning/caution/attention callout

> [!FAILURE]
> A simple failure/fail/missing callout

> [!DANGER]
> A simple danger/error callout

> [!BUG]
> A simple bug callout

> [!EXAMPLE]
> A simple example callout

> [!QUOTE]
> A simple quote/cite callout

## Tables

| Tables        | Are           | Cool  |
| ------------- |:-------------:| -----:|
| This column     | is left-aligned | $1600 |
| This one      | is centered      |   $12 |
| And this one | is right-aligned      |    $1 |

## Code

```js
// Here's what JavaScript code looks like
const sampleElement = "secondBrain";
const sampleObject = {
    fill: "this",
    in: true,
    the: null,
    blanks: 123123
};
```